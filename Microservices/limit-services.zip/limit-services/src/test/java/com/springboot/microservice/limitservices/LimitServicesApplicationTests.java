package com.springboot.microservice.limitservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
